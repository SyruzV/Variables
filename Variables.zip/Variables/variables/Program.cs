﻿Console.WriteLine("Variables!");

//Declaraciones
Console.WriteLine("Declaraciones");
int age = 18;
char initial = 'F';
string lastName = "Valverde";
decimal score = 99.9M;
double grade = 45.0D;
float distance = 5647.6547F;
bool enabled = false;

Console.WriteLine(age);
Console.WriteLine(initial);
Console.WriteLine(lastName);
Console.WriteLine(score);
Console.WriteLine(grade);
Console.WriteLine(distance);
Console.WriteLine(enabled);

//Re-asignaciones
Console.WriteLine("InResignaciones");
age = 18;
initial = 'J';
lastName = "Montero";

Console.WriteLine(age);
Console.WriteLine(initial);
Console.WriteLine(lastName);

//Operaciones
Console.WriteLine("Operaciones!!");
double EduardoScore = 80.0D;
double davidScore = 89.5D;
double marioScore = 73.33D;
double joseIScore = 65.0D;

double average;

double total = EduardoScore + davidScore + marioScore + joseIScore;

average = total / 4;

Console.WriteLine(average);